package com.example.aashya.thereadingroom;

/**
 * Created by aashya on 27/03/15.
 */



public class unknownresourceexception extends RuntimeException {

    public unknownresourceexception() {
        super();
    }

    public unknownresourceexception(String s) {
        super(s);
    }

    public unknownresourceexception(String s, Throwable throwable) {
        super(s, throwable);
    }

    public unknownresourceexception(Throwable throwable) {
        super(throwable);
    }
}
