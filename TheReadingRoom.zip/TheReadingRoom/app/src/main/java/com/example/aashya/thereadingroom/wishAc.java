package com.example.aashya.thereadingroom;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by aashya on 27/03/15.
 */
public class wishAc extends Activity{



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*
        setContentView(R.layout.wish);
        Button a = (Button) findViewById(R.id.add);


        a.setOnClickListener(new View.OnClickListener()

        {
            public void onClick(View v) {

            }
        });
*/
    }

}
