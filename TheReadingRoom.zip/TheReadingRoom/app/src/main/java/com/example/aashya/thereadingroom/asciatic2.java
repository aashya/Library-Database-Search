package com.example.aashya.thereadingroom;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

/**
 * Created by aashya on 27/03/15.
 */
public class asciatic2 extends ActionBarActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.asciatic2);
    }
}
