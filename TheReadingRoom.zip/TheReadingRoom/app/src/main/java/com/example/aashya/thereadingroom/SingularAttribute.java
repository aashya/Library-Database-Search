package com.example.aashya.thereadingroom;

/**
 * Created by aashya on 27/03/15.
 */
public class SingularAttribute {
}
